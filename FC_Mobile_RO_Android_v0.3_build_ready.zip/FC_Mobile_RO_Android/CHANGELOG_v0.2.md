# FC Mobile RO v0.2

- Added local playable demo mode when Supabase credentials are not configured.
- Added sample squad cards and attribute detail dialogs.
- Added progressive player training up to level 30.
- Added simulated 1,000,000 coin pack opening.
- Added Icon spin flow with two free spins and 500/750 FC Point costs.
- Added Ballon d'Or Week 2 demo with 20 match nodes and token rewards.
- Added Training Transfer token counter and 3,000-token gate.
- Preserved the initial Supabase auth/admin scaffold for the online phase.
