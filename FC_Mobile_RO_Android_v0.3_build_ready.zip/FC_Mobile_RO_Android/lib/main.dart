import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty) {
    await Supabase.initialize(url: supabaseUrl, anonKey: supabaseAnonKey);
  }
  runApp(const FcMobileRoApp());
}

bool get backendReady => supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;
final supa = backendReady ? Supabase.instance.client : null;

const bg = Color(0xFF07111F);
const panel = Color(0xFF101F32);
const gold = Color(0xFFE7B84B);
const green = Color(0xFF38C987);

class FcMobileRoApp extends StatelessWidget {
  const FcMobileRoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FC Mobile RO',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark),
        useMaterial3: true,
        cardTheme: CardThemeData(color: panel, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
      ),
      home: !backendReady ? const LocalDemoHome() : const AuthGate(),
    );
  }
}


class LocalDemoHome extends StatefulWidget {
  const LocalDemoHome({super.key});
  @override
  State<LocalDemoHome> createState() => _LocalDemoHomeState();
}

class DemoPlayer {
  DemoPlayer(this.name, this.position, this.ovr, this.level, this.color);
  final String name, position;
  int ovr, level;
  final Color color;
}

class _LocalDemoHomeState extends State<LocalDemoHome> {
  int tab = 0;
  int coins = 5000000, gems = 10000, fcPoints = 30000, transferTokens = 3000;
  int spins = 0, matches = 0;
  final List<DemoPlayer> players = [
    DemoPlayer('ZIDANE', 'CAM', 135, 0, const Color(0xFFB68B39)),
    DemoPlayer('RONALDO', 'ST', 134, 12, const Color(0xFFB68B39)),
    DemoPlayer('MESSI', 'RW', 133, 8, const Color(0xFF8D70C9)),
    DemoPlayer('MALDINI', 'CB', 132, 0, const Color(0xFF8D70C9)),
    DemoPlayer('YASHIN', 'GK', 131, 4, const Color(0xFF4C9D8A)),
  ];
  void notice(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  void train(DemoPlayer p) {
    if (p.level >= 30) { notice('${p.name} este deja la nivelul 30.'); return; }
    final cost = 12000 + p.level * 8500;
    if (coins < cost) { notice('Nu ai suficiente coins. Cost: ${cost.toString()}'); return; }
    setState(() { coins -= cost; p.level++; p.ovr += p.level % 3 == 0 ? 1 : 0; });
    notice('${p.name}: antrenament ${p.level}/30. Atributele au crescut!');
  }
  void openPack() {
    const cost = 1000000;
    if (coins < cost) { notice('Nu ai suficiente coins pentru pachet.'); return; }
    setState(() { coins -= cost; });
    final p = DemoPlayer('ICON NOU', 'CM', 128 + (DateTime.now().millisecond % 7), 0, const Color(0xFFB68B39));
    showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: panel, title: const Text('PACHET DESCHIS'), content: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.auto_awesome, color: gold, size: 44), const SizedBox(height: 10), Text('${p.name} • ${p.ovr} OVR', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: gold)), const Text('Jucător demonstrativ')]), actions: [TextButton(onPressed: () { setState(() => players.add(p)); Navigator.pop(context); }, child: const Text('ADAUGĂ ÎN ECHIPĂ'))]));
  }
  void spin() {
    final cost = spins < 2 ? 0 : (spins == 2 ? 500 : spins == 3 ? 750 : 1000 + (spins - 4) * 500);
    if (fcPoints < cost) { notice('Nu ai suficiente FC Points.'); return; }
    setState(() { fcPoints -= cost; spins++; });
    final rewards = ['Zidane 135 OVR', '5.000 gems', 'Rank Up Tokens', 'Jucător 130+ OVR'];
    final reward = rewards[(spins - 1) % rewards.length];
    if (reward.contains('gems')) setState(() => gems += 5000);
    showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: panel, title: const Text('RECOMPENSĂ'), content: Text(reward, style: const TextStyle(color: gold, fontSize: 22, fontWeight: FontWeight.bold)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('CONTINUĂ'))]));
  }
  @override
  Widget build(BuildContext context) {
    final pages = [dashboard(), squad(), events(), store()];
    return Scaffold(
      appBar: AppBar(title: const Text('FC MOBILE RO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), actions: [Padding(padding: const EdgeInsets.only(right: 12), child: Center(child: Text('DEMO', style: TextStyle(color: gold, fontWeight: FontWeight.w900))))]),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(backgroundColor: panel, selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Acasă'), NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'Echipa'), NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Evenimente'), NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'Magazin')]),
    );
  }
  Widget balance() => Wrap(spacing: 8, runSpacing: 8, children: [pill(Icons.monetization_on, '$coins COINS'), pill(Icons.diamond, '$gems GEMS'), pill(Icons.stars, '$fcPoints FC')]);
  Widget pill(IconData i, String s) => Chip(avatar: Icon(i, color: gold, size: 17), label: Text(s, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)), backgroundColor: panel, side: BorderSide.none);
  Widget dashboard() => ListView(padding: const EdgeInsets.all(16), children: [Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF174653), Color(0xFF17223B)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('BINE AI VENIT ÎN', style: TextStyle(color: Colors.white70, letterSpacing: 2)), Text('FC MOBILE RO', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)), SizedBox(height: 6), Text('Construiește-ți echipa. Scrie-ți legenda.', style: TextStyle(color: Colors.white70))]),), const SizedBox(height: 12), balance(), const SizedBox(height: 12), const SectionTitle('MODURI DE JOC'), EventCard(title: 'ECHIPA MEA', subtitle: 'Gestionează primul 11 și antrenează jucătorii', icon: Icons.groups), EventCard(title: 'BALONUL DE AUR', subtitle: 'Meciuri, skill games și recompense', icon: Icons.emoji_events), EventCard(title: 'BOX ICON', subtitle: 'Primele două rotiri sunt gratuite', icon: Icons.auto_awesome), const SizedBox(height: 10), const InfoTile(icon: Icons.info_outline, title: 'Versiune demonstrativă', detail: 'Progresul este local și temporar în această etapă. Conturile online și sincronizarea vor fi conectate separat.')]);
  Widget squad() => ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle('ECHIPA MEA'), const SizedBox(height: 8), Container(height: 130, decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), gradient: const LinearGradient(colors: [Color(0xFF176044), Color(0xFF0C302A)])), child: const Center(child: Text('FORMAȚIE 4-3-3\nOVR 133', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),), const SizedBox(height: 12), ...players.map((p) => Card(child: ListTile(leading: Container(width: 48, height: 58, decoration: BoxDecoration(color: p.color.withOpacity(.22), borderRadius: BorderRadius.circular(9), border: Border.all(color: p.color)), child: Center(child: Text('${p.ovr}', style: TextStyle(color: p.color, fontWeight: FontWeight.w900, fontSize: 18)))), title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w900)), subtitle: Text('${p.position} • Antrenament ${p.level}/30'), trailing: IconButton(icon: const Icon(Icons.fitness_center, color: gold), onPressed: () => train(p)), onTap: () => showDialog(context: context, builder: (_) => AlertDialog(backgroundColor: panel, title: Text('${p.name} • ${p.ovr} OVR'), content: Text('Pace ${p.ovr - 1 + p.level}  •  Shooting ${p.ovr - 3 + p.level}\nPassing ${p.ovr - 8 + p.level}  •  Defending ${p.ovr - 10 + p.level}\nDribbling ${p.ovr - 2 + p.level}  •  Physical ${p.ovr - 6 + p.level}'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ÎNCHIDE'))])))), const SizedBox(height: 8), const Text('Apasă pe card pentru a vedea atributele. Apasă pe ganteră pentru antrenament.', style: TextStyle(color: Colors.white60, fontSize: 12))]);
  Widget events() => ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle('BALONUL DE AUR • SĂPTĂMÂNA 2'), const SizedBox(height: 8), EventCard(title: '20 DE MECIURI', subtitle: 'Fiecare victorie oferă recompense diferite', icon: Icons.sports_soccer), ...List.generate(20, (i) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: panel, child: Text('${i+1}')), title: Text('Meciul ${i+1}'), subtitle: Text(i % 3 == 0 ? 'Recompensă: Rank Up Token' : i % 3 == 1 ? 'Recompensă: Training Transfer Token' : 'Recompensă: Coins + Gems'), trailing: FilledButton(onPressed: i == matches ? () => setState(() { matches++; transferTokens += 150; gems += 250; }) : null, child: Text(i < matches ? 'JUCAT' : i == matches ? 'JOACĂ' : 'BLOCAT'))))), const SizedBox(height: 8), Text('Progres: $matches/20 meciuri'), if (matches == 20) const EventCard(title: 'RECOMPENSĂ FINALĂ', subtitle: 'Pachet jucător 133–135 OVR', icon: Icons.card_giftcard)]);
  Widget store() => ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle('MAGAZIN'), const SizedBox(height: 8), Card(child: ListTile(leading: const Icon(Icons.inventory_2, color: gold, size: 32), title: const Text('PACHET 1.000.000 COINS'), subtitle: const Text('Deschide și primește un jucător'), trailing: FilledButton(onPressed: openPack, child: const Text('DESCHIDE')))), const SizedBox(height: 12), Card(child: ListTile(leading: const Icon(Icons.auto_awesome, color: gold, size: 32), title: const Text('BOXUL ICON • ZIDANE'), subtitle: Text('Rotiri: $spins • următoarea: ${spins < 2 ? 'GRATUITĂ' : spins == 2 ? '500' : spins == 3 ? '750' : 'FC POINTS'}'), trailing: FilledButton(onPressed: spin, child: const Text('ROTEȘTE')))), Card(child: ListTile(leading: const Icon(Icons.swap_horiz, color: gold), title: const Text('TRAINING TRANSFER'), subtitle: Text('$transferTokens / 3.000 tokens'), trailing: FilledButton(onPressed: () { if (transferTokens < 3000) { notice('Mai ai nevoie de ${3000-transferTokens} tokens.'); return; } setState(() => transferTokens -= 3000); notice('Transfer demonstrativ disponibil: selectează jucătorii în următoarea versiune.'); }, child: const Text('TRANSFER')))), const SizedBox(height: 10), const InfoTile(icon: Icons.lock_outline, title: 'Versiune de test', detail: 'Plățile reale și cumpărarea FC Points nu sunt activate.')]);
}

class SetupScreen extends StatelessWidget {
  const SetupScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Padding(
      padding: const EdgeInsets.all(28),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const BrandMark(),
        const SizedBox(height: 24),
        const Text('FC MOBILE RO', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, letterSpacing: 2)),
        const SizedBox(height: 12),
        const Text('Proiectul Android este pregătit. Pentru conectarea conturilor și aprobarea jucătorilor trebuie configurat serverul Supabase.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, height: 1.5)),
        const SizedBox(height: 20),
        const InfoTile(icon: Icons.cloud_outlined, title: 'Server online neconfigurat', detail: 'Adaugă URL-ul și cheia publică Supabase la compilare.'),
      ]),
    )),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<AuthState>(
    stream: supa!.auth.onAuthStateChange,
    builder: (context, snapshot) {
      final user = supa!.auth.currentUser;
      if (user == null) return const LoginScreen();
      return FutureBuilder<Map<String, dynamic>?>(
        future: supa!.from('profiles').select().eq('id', user.id).maybeSingle(),
        builder: (context, profile) {
          if (profile.connectionState != ConnectionState.done) return const LoadingScreen();
          if (profile.hasError || profile.data == null) return const PendingScreen(message: 'Profilul nu este încă pregătit. Contactează administratorul.');
          final p = profile.data!;
          if (p['status'] != 'approved') return const PendingScreen(message: 'Cererea ta de acces a fost trimisă. Poți juca după aprobarea administratorului.');
          return p['role'] == 'admin' ? const AdminHome() : const PlayerHome();
        },
      );
    },
  );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  final nickname = TextEditingController();
  bool create = false, busy = false;
  String? error;
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      if (create) {
        final result = await supa!.auth.signUp(email: email.text.trim(), password: password.text);
        final id = result.user?.id;
        if (id != null) {
          await supa!.from('profiles').insert({'id': id, 'nickname': nickname.text.trim(), 'role': 'player', 'status': 'pending'});
        }
      } else {
        await supa!.auth.signInWithPassword(email: email.text.trim(), password: password.text);
      }
    } catch (e) { setState(() => error = 'Nu am putut continua: $e'); }
    if (mounted) setState(() => busy = false);
  }
  @override
  void dispose() { email.dispose(); password.dispose(); nickname.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 440), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const BrandMark(), const SizedBox(height: 18),
        const Text('FC MOBILE RO', textAlign: TextAlign.center, style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: 2)),
        const Text('Intră în joc. Construiește-ți echipa.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
        const SizedBox(height: 28),
        Text(create ? 'CERE ACCES' : 'CONECTARE', style: const TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
        if (create) ...[const SizedBox(height: 12), TextField(controller: nickname, decoration: const InputDecoration(labelText: 'Nume de joc', prefixIcon: Icon(Icons.person_outline)))],
        const SizedBox(height: 12), TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined))),
        const SizedBox(height: 12), TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Parolă', prefixIcon: Icon(Icons.lock_outline))),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(error!, style: const TextStyle(color: Colors.redAccent))),
        const SizedBox(height: 18),
        FilledButton(style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: bg, padding: const EdgeInsets.symmetric(vertical: 16)), onPressed: busy ? null : submit, child: Text(busy ? 'SE CONECTEAZĂ...' : create ? 'TRIMITE CEREREA' : 'INTRĂ ÎN JOC', style: const TextStyle(fontWeight: FontWeight.w900))),
        TextButton(onPressed: () => setState(() { create = !create; error = null; }), child: Text(create ? 'Ai deja cont? Conectează-te' : 'Nu ai cont? Cere acces administratorului')),
        const SizedBox(height: 12), const Text('Accesul la joc este permis numai după aprobarea administratorului.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
      ]),
    )))),
  );
}

class PendingScreen extends StatelessWidget {
  final String message;
  const PendingScreen({super.key, required this.message});
  @override
  Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.hourglass_top_rounded, size: 64, color: gold), const SizedBox(height: 18),
    const Text('ACCES ÎN AȘTEPTARE', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const SizedBox(height: 12),
    Text(message, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, height: 1.5)), const SizedBox(height: 20),
    OutlinedButton(onPressed: () => supa!.auth.signOut(), child: const Text('Deconectare')),
  ]))));
}

class LoadingScreen extends StatelessWidget {
  const LoadingScreen({super.key});
  @override
  Widget build(BuildContext context) => const Scaffold(body: Center(child: CircularProgressIndicator(color: gold)));
}

class PlayerHome extends StatefulWidget {
  const PlayerHome({super.key});
  @override
  State<PlayerHome> createState() => _PlayerHomeState();
}
class _PlayerHomeState extends State<PlayerHome> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const GameDashboard(), const SquadScreen(), const EventsScreen(), const StoreScreen()];
    return Scaffold(
      appBar: AppBar(title: const Text('FC MOBILE RO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)), actions: [IconButton(onPressed: () => supa!.auth.signOut(), icon: const Icon(Icons.logout))]),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(backgroundColor: panel, selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Acasă'),
        NavigationDestination(icon: Icon(Icons.groups_outlined), label: 'Echipa'),
        NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Evenimente'),
        NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'Magazin'),
      ]),
    );
  }
}

class GameDashboard extends StatelessWidget {
  const GameDashboard({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFF173D48), Color(0xFF14223B)])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('BUN VENIT ÎN', style: TextStyle(color: Colors.white70, letterSpacing: 2)), const Text('FC MOBILE RO', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)), const SizedBox(height: 14),
      const Row(children: [Icon(Icons.diamond, color: Color(0xFF59D5F2)), SizedBox(width: 8), Text('GEMURI', style: TextStyle(color: Colors.white70)), Spacer(), Text('—', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))]),
      const SizedBox(height: 8), const Row(children: [Icon(Icons.monetization_on, color: gold), SizedBox(width: 8), Text('COINS', style: TextStyle(color: Colors.white70)), Spacer(), Text('—', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))]),
    ]),
    const SizedBox(height: 18), const SectionTitle('MODURI DE JOC'),
    const GridTileCard(icon: Icons.groups, title: 'Echipa mea', subtitle: 'Construiește primul 11'),
    const GridTileCard(icon: Icons.card_giftcard, title: 'Pachete', subtitle: 'Deschide recompense'),
    const GridTileCard(icon: Icons.emoji_events, title: 'Evenimente', subtitle: 'Misiuni și recompense noi'),
    const SizedBox(height: 12), const InfoTile(icon: Icons.cloud_done_outlined, title: 'Cont online', detail: 'Progresul va fi sincronizat cu serverul după configurarea bazei de date.'),
  ]);
}

class SquadScreen extends StatelessWidget {
  const SquadScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const SectionTitle('ECHIPA MEA'), const SizedBox(height: 8),
    Container(height: 310, decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF15563E), Color(0xFF0C302A)])), child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.sports_soccer, size: 54, color: Colors.white24), SizedBox(height: 8), Text('TERENUL TĂU', style: TextStyle(letterSpacing: 2, color: Colors.white70)), Text('Echipa va fi încărcată din contul online', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54))]))),
    const SizedBox(height: 14), const InfoTile(icon: Icons.trending_up, title: 'Antrenament', detail: 'Sistemul de antrenament și transfer va fi conectat în următoarea etapă.'),
  ]);
}

class EventsScreen extends StatelessWidget {
  const EventsScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    SectionTitle('EVENIMENTE'), SizedBox(height: 8),
    EventCard(title: 'BALONUL DE AUR', subtitle: 'Eveniment principal • actualizări săptămânale', icon: Icons.workspace_premium),
    EventCard(title: 'EVENIMENTUL DE VINERI', subtitle: 'Conținut publicat automat la 07:00 după aprobarea administratorului', icon: Icons.calendar_month),
    EventCard(title: 'MISIUNI SĂPTĂMÂNALE', subtitle: 'Recompense și progres', icon: Icons.flag),
  ]);
}

class StoreScreen extends StatelessWidget {
  const StoreScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    SectionTitle('MAGAZIN'), SizedBox(height: 8),
    EventCard(title: 'PACHETE DE JUCĂTORI', subtitle: 'Pachete cu fotbaliști și recompense', icon: Icons.inventory_2),
    EventCard(title: 'BOXUL ICON', subtitle: 'Rotație programată marți la 07:00', icon: Icons.auto_awesome),
    EventCard(title: 'RECOMPENSA SĂPTĂMÂNALĂ', subtitle: '10.000 gemuri în fiecare luni la 07:00', icon: Icons.diamond),
  ]);
}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}
class _AdminHomeState extends State<AdminHome> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    final pages = [const AdminDashboard(), const ApprovalScreen(), const AdminScheduleScreen()];
    return Scaffold(
      appBar: AppBar(title: const Text('FC MOBILE RO • ADMIN', style: TextStyle(fontWeight: FontWeight.w900, color: gold)), actions: [IconButton(onPressed: () => supa!.auth.signOut(), icon: const Icon(Icons.logout))]),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(backgroundColor: panel, selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Panou'),
        NavigationDestination(icon: Icon(Icons.verified_user_outlined), label: 'Aprobări'),
        NavigationDestination(icon: Icon(Icons.schedule), label: 'Program'),
      ]),
    );
  }
}

class AdminDashboard extends StatelessWidget {
  const AdminDashboard({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    Text('PANOU DE CONTROL', style: TextStyle(color: gold, fontWeight: FontWeight.w900, letterSpacing: 1.5)),
    SizedBox(height: 12), GridTileCard(icon: Icons.admin_panel_settings, title: 'Administrator principal', subtitle: 'Contul tău are permisiuni speciale'),
    GridTileCard(icon: Icons.people_alt_outlined, title: 'Cereri de acces', subtitle: 'Aprobă sau respinge jucători noi'),
    GridTileCard(icon: Icons.edit_calendar, title: 'Editor de evenimente', subtitle: 'Pregătește actualizarea de vineri'),
    InfoTile(icon: Icons.shield_outlined, title: 'Securitate', detail: 'Rolul de administrator este stabilit numai din baza de date, nu din aplicația instalată.'),
  ]);
}

class ApprovalScreen extends StatefulWidget {
  const ApprovalScreen({super.key});
  @override
  State<ApprovalScreen> createState() => _ApprovalScreenState();
}
class _ApprovalScreenState extends State<ApprovalScreen> {
  Future<void> changeStatus(String id, String status) async {
    await supa!.from('profiles').update({'status': status}).eq('id', id);
    setState(() {});
  }
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
    future: supa!.from('profiles').select('id,nickname,status,created_at').eq('role', 'player').eq('status', 'pending').order('created_at'),
    builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final rows = snap.data!;
      if (rows.isEmpty) return const Center(child: Text('Nu există cereri noi de acces.'));
      return ListView(padding: const EdgeInsets.all(16), children: rows.map((p) => Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person_outline)), title: Text((p['nickname'] ?? 'Jucător').toString()), subtitle: const Text('Cerere în așteptare'),
        trailing: Wrap(spacing: 4, children: [
          IconButton(tooltip: 'Aprobă', onPressed: () => changeStatus(p['id'], 'approved'), icon: const Icon(Icons.check_circle, color: green)),
          IconButton(tooltip: 'Respinge', onPressed: () => changeStatus(p['id'], 'rejected'), icon: const Icon(Icons.cancel, color: Colors.redAccent)),
        ]),
      ))).toList());
    },
  );
}

class AdminScheduleScreen extends StatelessWidget {
  const AdminScheduleScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    SectionTitle('PROGRAM AUTOMAT • EUROPE/BUCHAREST'),
    EventCard(title: 'LUNI • 07:00', subtitle: 'Acordă 10.000 gemuri fiecărui cont aprobat, o singură dată pe săptămână.', icon: Icons.diamond),
    EventCard(title: 'MARȚI • 07:00', subtitle: 'Rotește boxul Icon după configurația aprobată.', icon: Icons.autorenew),
    EventCard(title: 'VINERI • 07:00', subtitle: 'Publică evenimentul aprobat joi.', icon: Icons.rocket_launch),
    InfoTile(icon: Icons.info_outline, title: 'Programarea nu este încă activă', detail: 'Aceste sarcini trebuie configurate pe server înainte de lansarea publică.'),
  ]);
}

class BrandMark extends StatelessWidget {
  const BrandMark({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Container(width: 82, height: 82, decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), border: Border.all(color: gold, width: 2), gradient: const LinearGradient(colors: [Color(0xFF1A3850), Color(0xFF0B1728)])), child: const Icon(Icons.sports_soccer, color: gold, size: 44)));
}
class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Text(text, style: const TextStyle(color: gold, fontWeight: FontWeight.w900, letterSpacing: 1.4));
}
class GridTileCard extends StatelessWidget {
  final IconData icon; final String title, subtitle;
  const GridTileCard({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: gold, size: 30), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60))));
}
class EventCard extends StatelessWidget {
  final String title, subtitle; final IconData icon;
  const EventCard({super.key, required this.title, required this.subtitle, required this.icon});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(children: [Container(width: 48, height: 48, decoration: BoxDecoration(color: const Color(0x22E7B84B), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: gold)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12))]))])));
}
class InfoTile extends StatelessWidget {
  final IconData icon; final String title, detail;
  const InfoTile({super.key, required this.icon, required this.title, required this.detail});
  @override
  Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: gold), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(detail, style: const TextStyle(color: Colors.white60, height: 1.4))));
}
