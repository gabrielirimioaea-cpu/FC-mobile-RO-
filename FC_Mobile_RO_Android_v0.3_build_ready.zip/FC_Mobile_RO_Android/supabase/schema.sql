-- FC Mobile RO - schema initial pentru Supabase.
-- Rulează în Supabase SQL Editor. Nu publica cheia service_role în aplicația Android.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  nickname text not null default 'Jucător',
  role text not null default 'player' check (role in ('player','admin')),
  status text not null default 'pending' check (status in ('pending','approved','rejected','suspended')),
  created_at timestamptz not null default now()
);

create table if not exists public.wallets (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  gems bigint not null default 0 check (gems >= 0),
  coins bigint not null default 0 check (coins >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.event_configs (
  id bigint generated always as identity primary key,
  event_key text not null unique,
  title text not null,
  payload jsonb not null default '{}'::jsonb,
  starts_at timestamptz,
  approved_by uuid references public.profiles(id),
  approved_at timestamptz,
  published boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists public.weekly_gem_grants (
  id bigint generated always as identity primary key,
  user_id uuid not null references public.profiles(id) on delete cascade,
  week_key text not null,
  amount integer not null default 10000,
  granted_at timestamptz not null default now(),
  unique(user_id, week_key)
);

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and status = 'approved'
  );
$$;

alter table public.profiles enable row level security;
alter table public.wallets enable row level security;
alter table public.event_configs enable row level security;
alter table public.weekly_gem_grants enable row level security;

create policy "profiles read self or admin" on public.profiles
for select to authenticated using (id = auth.uid() or public.is_admin());

create policy "new users request player access" on public.profiles
for insert to authenticated with check (id = auth.uid() and role = 'player' and status = 'pending');

create policy "admin updates profiles" on public.profiles
for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "wallet read own or admin" on public.wallets
for select to authenticated using (user_id = auth.uid() or public.is_admin());

create policy "wallet admin manage" on public.wallets
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "approved users read published events" on public.event_configs
for select to authenticated using (
  published = true and exists (
    select 1 from public.profiles p where p.id = auth.uid() and p.status = 'approved'
  )
  or public.is_admin()
);

create policy "admin manages events" on public.event_configs
for all to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "user reads own gem grants" on public.weekly_gem_grants
for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- IMPORTANT: după ce creezi contul tău prin aplicație, rulează manual această comandă
-- în SQL Editor, înlocuind EMAILUL cu adresa contului tău. Nu acorda rolul admin altcuiva.
-- update public.profiles p set role='admin', status='approved'
-- from auth.users u where p.id=u.id and u.email='EMAILUL_TAU';
