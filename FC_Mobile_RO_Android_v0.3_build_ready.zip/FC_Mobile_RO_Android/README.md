# FC Mobile RO — Android project v0.2

Aceasta este o versiune de dezvoltare Flutter pentru Android. Include un prototip local interactiv și scheletul de conectare online.

## Funcții demonstrative incluse în v0.2
- Interfață Android cu Acasă / Echipa / Evenimente / Magazin.
- Lot demonstrativ cu carduri și atribute afișate la atingere.
- Antrenament până la nivelul 30, cu cost în coins care crește progresiv.
- Pachet demonstrativ de 1.000.000 coins.
- Box Icon demonstrativ: primele două rotiri gratuite, apoi 500 și 750 FC Points.
- Balonul de Aur – săptămâna 2: listă de 20 de meciuri și recompense demonstrative.
- Controale demonstrative pentru Training Transfer Tokens.
- Structura anterioară de autentificare Supabase, aprobare conturi și panou admin rămâne în proiect.

## Limitări importante
- Ecranul demonstrativ folosește date locale temporare; acestea nu sunt încă salvate permanent și nu se sincronizează online.
- Conectarea Supabase, aprobarea reală a conturilor, permisiunile admin securizate și programările automate trebuie configurate și testate pe server înainte de lansarea online.
- Pachetul de 1.000.000 coins, rotirile și recompensele sunt simulări de gameplay, nu tranzacții reale.
- Acesta este codul sursă al aplicației, nu un APK compilat.

## Compilare APK (când mediul Flutter + Android SDK este disponibil)
```bash
flutter pub get
flutter build apk --release
```
Pentru varianta online, configurează proiectul Supabase și compilează cu `--dart-define=SUPABASE_URL=... --dart-define=SUPABASE_ANON_KEY=...`.

Nu introduce niciodată cheia Supabase `service_role` în aplicația Android.

## Construire APK automat cu GitHub Actions
1. Încarcă acest proiect într-un repository GitHub nou (branch `main`).
2. Deschide fila **Actions** și permite rularea workflow-urilor dacă GitHub cere asta.
3. Alege workflow-ul **Build FC Mobile RO APK** și apasă **Run workflow** (sau așteaptă build-ul automat după push).
4. Când build-ul termină cu succes, deschide rularea și descarcă artifact-ul **FC-Mobile-RO-APK**. În interior se află `app-release.apk`.

Acest workflow compilează APK-ul folosind Flutter și Android SDK în runner-ul GitHub. APK-ul rezultat trebuie testat pe dispozitiv înainte de distribuire. Acest pas nu configurează automat backend-ul Supabase.


## Starea build-ului v0.2
- Workflow-ul verifică fișierele proiectului, generează platforma Android cu Flutter și produce un APK release.
- La fiecare rulare reușită, APK-ul este atașat ca artifact cu număr de build.
- Pentru a descărca APK-ul este necesar ca proiectul să fie într-un repository GitHub și workflow-ul să ruleze cu succes.
- Nu include chei private sau `service_role`; build-ul demonstrativ pornește în modul local până la configurarea backend-ului.
